__all__ = ["linear_proximal_svm","logistic_regression","naivebayes_gaussian","naivebayes_multinomial"]
