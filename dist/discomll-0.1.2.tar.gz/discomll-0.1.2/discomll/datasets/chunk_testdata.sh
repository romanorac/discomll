#/bin/bash.sh

ddfs chunk test:breast_cancer_cont ./breast_cancer_wisconsin_cont.txt
ddfs chunk test:breast_cancer_cont_test ./breast_cancer_wisconsin_cont_test.txt
ddfs chunk test:breast_cancer_disc ./breast_cancer_wisconsin_disc.txt
ddfs chunk test:breast_cancer_disc_test ./breast_cancer_wisconsin_disc_test.txt
ddfs chunk test:ex3 ./ex3.txt
ddfs chunk test:ex3_test ./ex3_test.txt
ddfs chunk test:ex4 ./ex4.txt
ddfs chunk test:iris ./iris.txt
ddfs chunk test:iris_test ./iris_test.txt
ddfs chunk test:regression_data1 ./regression_data1.txt
ddfs chunk test:regression_data2 ./regression_data2.txt
