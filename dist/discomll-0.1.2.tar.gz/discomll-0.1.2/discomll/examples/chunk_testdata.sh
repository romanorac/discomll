#/bin/bash.sh

cd ../datasets/
./chunk_testdata.sh